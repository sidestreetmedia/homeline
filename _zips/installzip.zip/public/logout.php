<?php
require __DIR__ . '/../src/bootstrap.php';
Auth::logout();
header('Location: /');
