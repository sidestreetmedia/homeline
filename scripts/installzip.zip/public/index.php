<?php
require __DIR__ . '/../src/bootstrap.php';
if (Auth::current()) { header('Location: /dashboard.php'); exit; }
view('home', [], 'HomeLine — turn your yard sign into a 24/7 lead line');
