<!-- ============================== HERO ============================== -->
<section class="lp-hero glass">
    <span class="lp-eyebrow">● For real estate agents</span>
    <h1>Your sign,<br>now it talks.</h1>
    <p class="lede">Put a local phone number on the yard sign. A passerby calls,
       hears a polished spoken tour of the home, and presses 1 to get the details
       texted to them. You capture the lead while they're standing in the driveway.</p>
    <div class="lp-cta-row">
        <a class="btn btn-primary" href="/signup.php">Get started — $5/home</a>
        <a class="btn btn-ghost" href="#how">See how it works</a>
    </div>
    <p class="lp-cta-note">No contracts. Cancel anytime. Set up your first home in minutes.</p>
</section>

<!-- ============================== HOW IT WORKS ============================== -->
<section class="lp-section" id="how">
    <div class="lp-section-head">
        <h2>Three steps from sign to lead</h2>
        <p>No app for the caller to download. It's just a phone call — the one thing
           every passerby already knows how to do.</p>
    </div>
    <div class="lp-steps">
        <div class="lp-step glass">
            <div class="num">1</div>
            <h3>Pick a local number</h3>
            <p>Search by area code and we provision a real local phone number
               instantly — one per home. Print it on the sign or flyer.</p>
        </div>
        <div class="lp-step glass">
            <div class="num">2</div>
            <h3>Add the description</h3>
            <p>Type the listing details and we generate a natural-sounding narration,
               or upload your own recording. It's cached and ready to play.</p>
        </div>
        <div class="lp-step glass">
            <div class="num">3</div>
            <h3>Callers press 1</h3>
            <p>During playback, the caller presses 1 and instantly gets your custom
               text — address, price, link, your number — on their phone.</p>
        </div>
    </div>
</section>

<!-- ============================== PHONE DEMO SPLIT ============================== -->
<section class="lp-section">
    <div class="lp-split">
        <div>
            <div class="lp-section-head" style="text-align:left;margin:0 0 18px">
                <h2 style="font-size:clamp(24px,3.4vw,32px)">A lead magnet that works while you sleep</h2>
            </div>
            <p style="color:var(--ink-dim);font-size:16px;line-height:1.6;max-width:480px">
               Every drive-by is a warm lead you're probably missing. The caller is
               literally at the property, interested enough to dial. HomeLine answers
               24/7, tells them about the home in your voice, and — the moment they
               press 1 — drops your message straight into their texts so you have a
               number to follow up with.</p>
            <div class="lp-cta-row" style="justify-content:flex-start;margin-top:24px">
                <a class="btn btn-primary" href="/signup.php">Create your account</a>
            </div>
        </div>
        <div>
            <div class="phone">
                <div class="notch"></div>
                <div class="screen">
                    <div class="call-row">
                        <div class="call-av"></div>
                        <div class="call-meta">
                            <div class="t">(864) 555-0142</div>
                            <div class="s">HomeLine • 0:18</div>
                        </div>
                    </div>
                    <div class="bubble">“Welcome to 214 Maple Avenue — a renovated
                        4-bedroom craftsman with a new kitchen, half-acre lot, and
                        a wraparound porch…”</div>
                    <div class="keypad-hint">Press 1 for details by text ▾</div>
                    <div class="sms">214 Maple Ave — $429,000, 4bd/2.5ba.
                        Open Sun 1–3. Tour &amp; photos: bit.ly/maple214 — Jordan, Realtor</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================== FEATURES ============================== -->
<section class="lp-section">
    <div class="lp-section-head">
        <h2>Everything handled for you</h2>
        <p>The phone number, the voice, the texts, the billing. You add a home; we
           run the rest.</p>
    </div>
    <div class="lp-features">
        <div class="lp-feature glass">
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg></div>
            <h3>Real local numbers</h3>
            <p>Instant provisioning by area code, one number per home. Delete the
               listing and the number is released automatically.</p>
        </div>
        <div class="lp-feature glass">
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/></svg></div>
            <h3>Lifelike narration</h3>
            <p>Type a description and get a natural spoken tour, generated once and
               cached for instant playback — or upload your own recording.</p>
        </div>
        <div class="lp-feature glass">
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
            <h3>Press-1 text capture</h3>
            <p>Callers get your custom message the instant they press 1 — and you get
               a real phone number to follow up with.</p>
        </div>
        <div class="lp-feature glass">
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg></div>
            <h3>One simple dashboard</h3>
            <p>All your homes, sorted by address, each with its number and audio
               status at a glance. Add or remove in seconds.</p>
        </div>
    </div>
</section>

<!-- ============================== PRICING ============================== -->
<section class="lp-section" id="pricing">
    <div class="lp-section-head">
        <h2>Simple, honest pricing</h2>
        <p>One flat rate per home. No setup fees, no contracts.</p>
    </div>
    <div class="lp-price glass">
        <div class="amt"><span>$</span>5<span>/mo</span></div>
        <div class="per">per home</div>
        <ul>
            <li><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> A dedicated local phone number</li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Narration or your own recording</li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Unlimited calls and press-1 texts</li>
            <li><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> No contracts — cancel anytime</li>
        </ul>
        <a class="btn btn-primary" style="width:100%;justify-content:center" href="/signup.php">Get started</a>
        <p class="lp-cta-note">Billed per active home. Add and remove as your listings change.</p>
    </div>
</section>

<!-- ============================== FAQ ============================== -->
<section class="lp-section">
    <div class="lp-section-head">
        <h2>Questions, answered</h2>
    </div>
    <div class="lp-faq">
        <div class="faq-item glass">
            <h3>Do callers need an app?</h3>
            <p>No. They dial the number on your sign like any phone call. The text
               arrives as a normal SMS. Nothing to download.</p>
        </div>
        <div class="faq-item glass">
            <h3>What happens when I sell the home?</h3>
            <p>Delete the listing and its phone number is released automatically.
               You're billed for the active home that month, and not after.</p>
        </div>
        <div class="faq-item glass">
            <h3>Can I use my own recording?</h3>
            <p>Yes. Generate a narration from text, or upload your own MP3 for any
               home — your choice per listing.</p>
        </div>
        <div class="faq-item glass">
            <h3>What goes in the press-1 text?</h3>
            <p>Whatever you want, per home — price, open-house times, a link to
               photos, your direct number. You write it; we send it.</p>
        </div>
        <div class="faq-item glass">
            <h3>How does billing work?</h3>
            <p>$5 per month for each active home, charged to your card on file. Add
               or remove homes anytime. No setup fees and no contracts.</p>
        </div>
    </div>
</section>

<!-- ============================== FINAL CTA ============================== -->
<section class="lp-final glass">
    <h2>Turn your next sign into a lead machine.</h2>
    <p>Set up your first home in a few minutes and put a number on the sign today.</p>
    <div class="lp-cta-row">
        <a class="btn btn-primary" href="/signup.php">Create your account</a>
        <a class="btn btn-ghost" href="/login.php">Sign in</a>
    </div>
</section>

<div class="lp-footer">
    HomeLine — by <a href="https://hellosidestreet.com" target="_blank" rel="noopener">Sidestreet</a>
</div>
